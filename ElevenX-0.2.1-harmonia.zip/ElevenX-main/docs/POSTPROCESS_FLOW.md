# Offline post-process flowchart

```
                    ┌─────────────────────┐
                    │  XTTS-v2 synthesize │
                    │  (24 kHz mono PCM)  │
                    └──────────┬──────────┘
                               │
              ┌────────────────┼────────────────┐
              │ watermark.enabled?              │
              │ (ethical provenance only)       │
              └────────────────┬────────────────┘
                               │
              ┌────────────────┼────────────────┐
              │ postprocess.dark.enabled?       │
              │ needs Dark package + checkpoint │
              │ bandwidth SR (e.g. 24→48 kHz)   │
              │ SKIP if no weights / fail       │
              └────────────────┬────────────────┘
                               │
              ┌────────────────┼────────────────┐
              │ codec.enabled? (HarmoniaCodec)  │
              │                                 │
              │ require_validated_weights:true  │
              │   → need weights + pass report  │
              │ allow_unvalidated_roundtrip:true│
              │   → NumPy path, NO quality claim│
              │ encode → decode experiment      │
              └────────────────┬────────────────┘
                               │
                    ┌──────────▼──────────┐
                    │  Final WAV / stream │
                    │  complete-waveform  │
                    └─────────────────────┘
```

## Important

- **Live WebSocket stream does not run this chain** (latency).
- Random-init / unvalidated HarmoniaCodec only proves the pipeline runs.
- It does **not** increase measured speech quality.
- “Millions/billions of nodes” are not installed by enabling this path.
- HUSH / kinetic DAW cores stay **outside** ElevenX; optional post only.

## Enable HarmoniaCodec (validated)

1. Train or obtain weights; record SHA-256.
2. Run encode/decode benchmark; set `quality_report.passed: true`.
3. Config:

```yaml
codec:
  enabled: true
  require_validated_weights: true
  weights_path: ./weights/harmonia.pt
  expected_weights_sha256: "<hex>"
  quality_report:
    weights_sha256: "<same hex>"
    benchmark_id: "bench-2026-10-27"
    passed: true
```

## Enable HarmoniaCodec (experiment only)

```yaml
codec:
  enabled: true
  require_validated_weights: true
  allow_unvalidated_roundtrip: true   # structural only
```

Vendored sources: `vendor/HarmoniaCodec/` (selftest must pass).

## Enable Dark SR

```bash
pip install -e /path/to/Dark-v2.0.0
```

```yaml
postprocess:
  dark:
    enabled: true
    checkpoint: ./runs/dark/final.pt
    target_sample_rate: 48000
```
