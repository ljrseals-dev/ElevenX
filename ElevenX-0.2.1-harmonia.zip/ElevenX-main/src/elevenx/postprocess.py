"""Optional offline post-process chain for finished waveforms.

Flow (each stage independently gated; all off by default):

    XTTS mono float32
         │
         ├─[dark]────── optional bandwidth super-resolution (needs checkpoint)
         │
         ├─[harmonia]── optional encode→decode round-trip (needs readiness OR
         │              explicit allow_unvalidated_roundtrip for experiments)
         │
         └─[watermark]─ optional ethical provenance mark

None of these stages improve measured speech quality until trained weights
and a passing quality report exist. Random-init HarmoniaCodec only verifies
pipeline structure (selftest), not perceptual enhancement.
"""
from __future__ import annotations

import hashlib
import logging
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

logger = logging.getLogger("elevenx.postprocess")


@dataclass
class PostprocessReport:
    """What ran and why — for logs and /v1/info honesty."""

    stages_run: list[str] = field(default_factory=list)
    stages_skipped: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    sample_rate: int = 0


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _try_dark(
    audio: np.ndarray,
    sample_rate: int,
    cfg: dict[str, Any],
    report: PostprocessReport,
) -> tuple[np.ndarray, int]:
    if not bool(cfg.get("enabled", False)):
        report.stages_skipped.append("dark")
        return audio, sample_rate

    checkpoint = cfg.get("checkpoint")
    if not checkpoint or not Path(checkpoint).is_file():
        report.stages_skipped.append("dark")
        report.notes.append("dark: enabled but checkpoint missing — skipped")
        return audio, sample_rate

    target_sr = int(cfg.get("target_sample_rate", 48000))
    if target_sr <= sample_rate:
        report.stages_skipped.append("dark")
        report.notes.append(
            f"dark: target_sr ({target_sr}) <= current ({sample_rate}) — skipped"
        )
        return audio, sample_rate

    try:
        # Optional dependency: `dark` package from Dark-v2.0.0
        from dark.inference import SRInference  # type: ignore
        from dark.checkpoint import load_checkpoint  # type: ignore
    except ImportError:
        report.stages_skipped.append("dark")
        report.notes.append(
            "dark: package not installed (pip install the Dark-v2.0.0 tree) — skipped"
        )
        return audio, sample_rate

    try:
        model, _meta = load_checkpoint(checkpoint, map_location="cpu")
        engine = SRInference(model, device="cpu")
        wav = np.asarray(audio, dtype=np.float32).reshape(1, -1)
        out = engine.upscale(wav, sample_rate, target_sr)
        out = np.asarray(out, dtype=np.float32).reshape(-1)
        if out.size == 0 or not np.isfinite(out).all():
            raise RuntimeError("dark produced empty or non-finite audio")
        peak = float(np.max(np.abs(out)))
        if peak > 1.0:
            out = out / peak
        report.stages_run.append("dark")
        report.notes.append(
            f"dark: {sample_rate} → {target_sr} Hz (quality depends on checkpoint)"
        )
        return out, target_sr
    except Exception as exc:  # noqa: BLE001
        report.stages_skipped.append("dark")
        report.notes.append(f"dark: failed ({exc}) — skipped")
        logger.warning("dark postprocess failed: %s", exc)
        return audio, sample_rate


def _try_harmonia(
    audio: np.ndarray,
    sample_rate: int,
    cfg: dict[str, Any],
    report: PostprocessReport,
    vendor_root: Path,
) -> tuple[np.ndarray, int]:
    """Optional HarmoniaCodec encode→decode.

    With require_validated_weights=true (default), readiness must pass.
    allow_unvalidated_roundtrip=true runs the pure-NumPy path on random/init
    weights for structural experiments only — it does NOT improve quality.
    """
    if not bool(cfg.get("enabled", False)):
        report.stages_skipped.append("harmonia")
        return audio, sample_rate

    require_validated = bool(cfg.get("require_validated_weights", True))
    allow_unvalidated = bool(cfg.get("allow_unvalidated_roundtrip", False))
    weights_path = cfg.get("weights_path")
    expected_sha = cfg.get("expected_weights_sha256")
    mode = str(cfg.get("mode", "good"))

    from .harmoniacodec import CodecQualityReport, check_harmonia_readiness

    quality_report = None
    report_cfg = cfg.get("quality_report") or {}
    if report_cfg.get("weights_sha256") and report_cfg.get("benchmark_id"):
        quality_report = CodecQualityReport(
            weights_sha256=str(report_cfg["weights_sha256"]),
            benchmark_id=str(report_cfg["benchmark_id"]),
            passed=bool(report_cfg.get("passed", False)),
        )

    readiness = check_harmonia_readiness(
        enabled=True,
        weights_path=weights_path,
        report=quality_report,
        expected_weights_sha256=expected_sha,
    )

    if require_validated and not readiness.ready:
        if not allow_unvalidated:
            report.stages_skipped.append("harmonia")
            report.notes.append(
                "harmonia: not ready — " + "; ".join(readiness.reasons)
            )
            return audio, sample_rate
        report.notes.append(
            "harmonia: UNVALIDATED round-trip (structural only; no quality claim)"
        )

    # Prefer installed package; fall back to vendored tree.
    harmonia_mod = None
    try:
        import harmonia as harmonia_mod  # type: ignore
    except ImportError:
        vendor_py = vendor_root / "HarmoniaCodec"
        if vendor_py.is_dir():
            sys.path.insert(0, str(vendor_py))
            try:
                import harmonia as harmonia_mod  # type: ignore
            except ImportError:
                harmonia_mod = None

    if harmonia_mod is None:
        report.stages_skipped.append("harmonia")
        report.notes.append("harmonia: module not importable — skipped")
        return audio, sample_rate

    try:
        Config = getattr(harmonia_mod, "Config")
        HarmoniaCodec = getattr(harmonia_mod, "HarmoniaCodec")
        cfg_hc = Config(sr=int(sample_rate))
        codec = HarmoniaCodec(cfg_hc)
        x = np.asarray(audio, dtype=np.float64).reshape(-1)
        enc = codec.encode(x, mode)
        out = np.asarray(codec.decode(enc), dtype=np.float32).reshape(-1)
        out_sr = int(sample_rate)
        if out.size == 0 or not np.isfinite(out).all():
            raise RuntimeError("harmonia round-trip non-finite or empty")
        peak = float(np.max(np.abs(out)))
        if peak > 1.0:
            out = out / peak
        report.stages_run.append("harmonia")
        if readiness.ready:
            report.notes.append(f"harmonia: validated round-trip mode={mode}")
        else:
            report.notes.append(
                f"harmonia: unvalidated round-trip mode={mode} (no quality claim)"
            )
        return out, int(out_sr)
    except Exception as exc:  # noqa: BLE001
        report.stages_skipped.append("harmonia")
        report.notes.append(f"harmonia: failed ({exc}) — skipped")
        logger.warning("harmonia postprocess failed: %s", exc)
        return audio, sample_rate


def apply_postprocess(
    audio: np.ndarray,
    sample_rate: int,
    config: dict[str, Any],
    *,
    vendor_root: Path | None = None,
) -> tuple[np.ndarray, int, PostprocessReport]:
    """Run the optional offline quality/experiment chain.

    Safe default: all stages skipped → identity.
    """
    report = PostprocessReport(sample_rate=sample_rate)
    root = vendor_root or Path(__file__).resolve().parents[2] / "vendor"

    post = config.get("postprocess") or {}
    dark_cfg = post.get("dark") or config.get("dark") or {}
    harmonia_cfg = post.get("harmonia") or config.get("codec") or {}

    audio, sample_rate = _try_dark(audio, sample_rate, dark_cfg, report)
    audio, sample_rate = _try_harmonia(
        audio, sample_rate, harmonia_cfg, report, root
    )

    # Watermark remains handled in engine when enabled (pre-existing path).
    report.sample_rate = sample_rate
    if not report.stages_run:
        report.notes.append("postprocess: identity (no optional stages ran)")
    return audio, sample_rate, report
