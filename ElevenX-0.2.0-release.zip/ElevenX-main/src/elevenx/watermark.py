"""Optional ethical audio watermarking via Meta AudioSeal.

Disabled by default. Install the optional extra and set
`watermark.enabled: true` in config only after reviewing AudioSeal's
license and behavior. Watermarking does not replace consent; it is a
post-synthesis provenance aid.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass(frozen=True)
class WatermarkResult:
    audio: np.ndarray
    sample_rate: int
    message: str
    applied: bool


class AudioWatermark:
    """Thin wrapper around AudioSeal. Raises clearly if the optional dependency is missing."""

    def __init__(self, device: str = "cpu") -> None:
        try:
            import torch
            from audioseal import AudioSeal
        except ImportError as exc:
            raise RuntimeError(
                "AudioSeal is not installed. Install with: pip install audioseal"
            ) from exc

        self._torch = torch
        self.device = device
        self.generator = AudioSeal.load_generator("audioseal_wm_16bits").to(device)
        self.detector = AudioSeal.load_detector("audioseal_detector_16bits").to(device)

    def embed(
        self,
        waveform: np.ndarray,
        sample_rate: int,
        message: str = "elevenx",
    ) -> WatermarkResult:
        if waveform.ndim > 1:
            waveform = np.mean(waveform, axis=-1)
        tensor = self._torch.from_numpy(waveform.astype(np.float32)).to(self.device)
        if tensor.dim() == 1:
            tensor = tensor.unsqueeze(0)

        payload = self.generator.encode_message(message)
        watermark = self.generator.get_watermark(
            tensor.unsqueeze(1), sample_rate, message=payload
        )
        watermarked = (tensor + watermark.squeeze(1)).squeeze(0).detach().cpu().numpy()
        return WatermarkResult(
            audio=watermarked.astype(np.float32),
            sample_rate=sample_rate,
            message=message,
            applied=True,
        )

    def detect(self, waveform: np.ndarray, sample_rate: int) -> dict[str, Any]:
        if waveform.ndim > 1:
            waveform = np.mean(waveform, axis=-1)
        tensor = self._torch.from_numpy(waveform.astype(np.float32)).to(self.device)
        if tensor.dim() == 1:
            tensor = tensor.unsqueeze(0)

        result = self.detector.detect_watermark(tensor.unsqueeze(1), sample_rate)
        return {
            "detected": bool(result["detected"].item()),
            "message": result.get("message", "unknown"),
            "confidence": float(result.get("confidence", 0.0)),
        }


def maybe_watermark(
    audio: np.ndarray,
    sample_rate: int,
    *,
    enabled: bool,
    message: str = "elevenx",
    device: str = "cpu",
) -> WatermarkResult:
    """No-op when disabled; never raises if the feature is off."""
    if not enabled:
        return WatermarkResult(
            audio=audio, sample_rate=sample_rate, message="", applied=False
        )
    wm = AudioWatermark(device=device)
    return wm.embed(audio, sample_rate, message=message)
