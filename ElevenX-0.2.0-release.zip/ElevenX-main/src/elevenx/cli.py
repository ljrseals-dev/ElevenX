"""ElevenX command-line interface for local production use."""
from __future__ import annotations

import argparse
import sys
from pathlib import Path


def _cmd_synthesize(args: argparse.Namespace) -> int:
    from .engine import ElevenXEngine

    config = args.config or "config.yaml"
    engine = ElevenXEngine(config)
    result = engine.synthesize(
        text=args.text,
        reference_audio=args.reference,
        language=args.language,
        emotion=args.emotion,
    )
    out = Path(args.output)
    engine.save_wav(result, out)
    print(f"Wrote {out} ({result.duration_seconds:.2f}s @ {result.sample_rate} Hz, emotion={result.emotion})")
    return 0


def _cmd_serve(args: argparse.Namespace) -> int:
    import os

    import uvicorn

    host = args.host
    if host not in ("127.0.0.1", "localhost", "::1") and not args.allow_remote:
        print(
            "Refusing to bind outside loopback. Pass --allow-remote only after you have "
            "added auth, TLS, rate limits, and a real consent/rights workflow. See SECURITY.md.",
            file=sys.stderr,
        )
        return 2

    if args.config:
        os.environ["ELEVENX_CONFIG"] = args.config

    uvicorn.run(
        "elevenx.api:app",
        host=host,
        port=args.port,
        log_level=args.log_level,
        workers=1,  # XTTS is not multi-worker safe on a single GPU context
    )
    return 0


def _cmd_info(_: argparse.Namespace) -> int:
    from importlib.metadata import PackageNotFoundError, version

    try:
        ver = version("elevenx")
    except PackageNotFoundError:
        ver = "0.2.0-dev"
    print(f"ElevenX {ver}")
    print("Mode: local-first complete-waveform synthesis (XTTS-v2)")
    print("Consent required. Loopback default. See SECURITY.md and docs/INTEGRATION_STATUS.md.")
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        prog="elevenx",
        description="ElevenX — local-first voice synthesis (respectful by design)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_info = sub.add_parser("info", help="Show version and operating mode")
    p_info.set_defaults(func=_cmd_info)

    p_synth = sub.add_parser("synthesize", help="Synthesize a WAV from text + reference")
    p_synth.add_argument("--text", "-t", required=True, help="Text to speak")
    p_synth.add_argument("--reference", "-r", required=True, help="Path to consented reference audio")
    p_synth.add_argument("--output", "-o", default="elevenx.wav", help="Output WAV path")
    p_synth.add_argument("--language", "-l", default="en")
    p_synth.add_argument("--emotion", "-e", default="neutral")
    p_synth.add_argument("--config", "-c", default=None, help="Path to config.yaml")
    p_synth.set_defaults(func=_cmd_synthesize)

    p_serve = sub.add_parser("serve", help="Run the local Voice Studio API")
    p_serve.add_argument("--host", default="127.0.0.1")
    p_serve.add_argument("--port", type=int, default=8000)
    p_serve.add_argument("--config", "-c", default=None)
    p_serve.add_argument("--log-level", default="info")
    p_serve.add_argument(
        "--allow-remote",
        action="store_true",
        help="Allow non-loopback bind (requires your own security controls)",
    )
    p_serve.set_defaults(func=_cmd_serve)

    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
