"""Local-first Voice Studio API. Do not expose publicly without security controls."""
from __future__ import annotations

import logging
import os
import tempfile
import threading
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.concurrency import run_in_threadpool
from fastapi.responses import FileResponse, JSONResponse
from starlette.background import BackgroundTask

from .emotions import Emotion
from .engine import ElevenXEngine

logger = logging.getLogger("elevenx.api")

app = FastAPI(
    title="ElevenX",
    version="0.2.0",
    description="Local-first voice synthesis. Consent required. Loopback recommended.",
)
_engine: ElevenXEngine | None = None
_engine_lock = threading.Lock()
# XTTS models and GPU contexts are not assumed to be safe for concurrent calls.
# Reject overlapping requests rather than allowing an unbounded queue to build up.
_synthesis_slot = threading.Lock()
_WEB_APP = Path(__file__).resolve().parent / "static" / "index.html"
_MAX_UPLOAD_BYTES = 25 * 1024 * 1024
_ALLOWED_SUFFIXES = {".wav", ".flac", ".ogg", ".aiff", ".aif"}


def get_engine() -> ElevenXEngine:
    global _engine
    if _engine is None:
        with _engine_lock:
            if _engine is None:
                _engine = ElevenXEngine(os.environ.get("ELEVENX_CONFIG", "config.yaml"))
    return _engine


@app.get("/", include_in_schema=False)
def web_app() -> FileResponse:
    """Serve the local Voice Studio frontend."""
    if not _WEB_APP.is_file():
        raise HTTPException(status_code=500, detail="ElevenX web interface is missing")
    return FileResponse(_WEB_APP, media_type="text/html; charset=utf-8")


@app.get("/health")
def health() -> dict[str, str]:
    """Liveness probe — process is up. Does not load the model."""
    return {
        "status": "ok",
        "service": "ElevenX",
        "version": "0.2.0",
        "interface": "web",
        "mode": "complete-waveform",
    }


@app.get("/ready")
def ready() -> JSONResponse:
    """Readiness: engine can be constructed. Model stays lazy until first synthesize."""
    try:
        engine = get_engine()
        busy = _synthesis_slot.locked()
        return JSONResponse(
            {
                "status": "ready",
                "device": engine.device,
                "sample_rate": engine.sample_rate,
                "model_loaded": engine._tts is not None,
                "synthesis_busy": busy,
            }
        )
    except Exception as exc:
        logger.exception("Readiness check failed")
        return JSONResponse(
            {"status": "not_ready", "detail": str(exc)},
            status_code=503,
        )


@app.get("/v1/info")
def info() -> dict:
    """Public capability statement — honest limits, no performance theater."""
    return {
        "name": "ElevenX",
        "version": "0.2.0",
        "mode": "local-first complete-waveform",
        "backend": "Coqui XTTS-v2",
        "consent_required": True,
        "streaming": True,  # progressive sentence chunks over WebSocket
        "max_text_characters": 5000,
        "max_reference_bytes": _MAX_UPLOAD_BYTES,
        "emotions": [e.value for e in Emotion],
        "notes": [
            "Emotion presets are style hints, not calibrated emotion control.",
            "Bind to 127.0.0.1 for local use. See SECURITY.md before any remote exposure.",
            "Concurrent synthesis is rejected with HTTP 503 + Retry-After.",
        ],
    }


@app.post("/v1/synthesize")
async def synthesize(
    text: str = Form(..., max_length=5000),
    language: str = Form("en", min_length=2, max_length=12),
    emotion: str = Form("neutral"),
    consent: bool = Form(...),
    reference_audio: UploadFile = File(...),
) -> FileResponse:
    """Generate a WAV. Requires consent. One synthesis at a time."""
    if not consent:
        await reference_audio.close()
        raise HTTPException(
            status_code=403,
            detail="Confirm permission to use the reference voice",
        )
    if not text.strip():
        await reference_audio.close()
        raise HTTPException(status_code=422, detail="Text must not be empty")
    try:
        selected_emotion = Emotion(emotion)
    except ValueError as exc:
        await reference_audio.close()
        choices = ", ".join(item.value for item in Emotion)
        raise HTTPException(
            status_code=422,
            detail=f"Unsupported emotion. Choose one of: {choices}",
        ) from exc

    suffix = Path(reference_audio.filename or "reference.wav").suffix.lower()
    if suffix not in _ALLOWED_SUFFIXES:
        await reference_audio.close()
        raise HTTPException(status_code=415, detail="Unsupported reference audio format")

    reference_path: Path | None = None
    output_path: Path | None = None
    slot_acquired = False
    try:
        total = 0
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as handle:
            reference_path = Path(handle.name)
            while True:
                chunk = await reference_audio.read(1024 * 1024)
                if not chunk:
                    break
                total += len(chunk)
                if total > _MAX_UPLOAD_BYTES:
                    raise HTTPException(status_code=413, detail="Reference audio exceeds 25 MiB")
                handle.write(chunk)
        if total == 0:
            raise HTTPException(status_code=400, detail="Reference audio file is empty")

        slot_acquired = _synthesis_slot.acquire(blocking=False)
        if not slot_acquired:
            raise HTTPException(
                status_code=503,
                detail="ElevenX is already synthesizing audio. Wait for it to finish, then retry.",
                headers={"Retry-After": "3"},
            )

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as handle:
            output_path = Path(handle.name)

        engine = get_engine()
        result = await run_in_threadpool(
            engine.synthesize,
            text.strip(),
            reference_path,
            language,
            selected_emotion.value,
        )
        await run_in_threadpool(engine.save_wav, result, output_path)
        logger.info(
            "synthesis ok duration=%.2fs rate=%d emotion=%s",
            result.duration_seconds,
            result.sample_rate,
            result.emotion,
        )

        def cleanup() -> None:
            if reference_path is not None:
                reference_path.unlink(missing_ok=True)
            if output_path is not None:
                output_path.unlink(missing_ok=True)

        return FileResponse(
            path=output_path,
            media_type="audio/wav",
            filename="elevenx.wav",
            background=BackgroundTask(cleanup),
        )
    except HTTPException:
        if reference_path is not None:
            reference_path.unlink(missing_ok=True)
        if output_path is not None:
            output_path.unlink(missing_ok=True)
        raise
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        if reference_path is not None:
            reference_path.unlink(missing_ok=True)
        if output_path is not None:
            output_path.unlink(missing_ok=True)
        logger.warning("synthesis client error: %s", exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception:
        if reference_path is not None:
            reference_path.unlink(missing_ok=True)
        if output_path is not None:
            output_path.unlink(missing_ok=True)
        logger.exception("synthesis failed")
        raise
    finally:
        if slot_acquired:
            _synthesis_slot.release()
        await reference_audio.close()


@app.websocket("/v1/synthesize/stream")
async def synthesize_stream(websocket: WebSocket) -> None:
    """Progressive sentence-level PCM stream over WebSocket.

    Protocol (client → server, single JSON text frame after accept):
      {
        "text": "...",
        "language": "en",
        "emotion": "neutral",
        "consent": true,
        "reference_b64": "<base64 of reference audio bytes>",
        "reference_suffix": ".wav"
      }

    Protocol (server → client):
      text frames with JSON metadata, then binary frames of float32 little-endian PCM:
        {"type":"meta","sample_rate":24000,"emotion":"neutral","total_chunks":N}
        {"type":"chunk","index":0,"total":N,"text":"...","duration_seconds":1.2,"is_final":false}
        <binary float32 PCM>
        ...
        {"type":"done","chunks":N}
      On error: {"type":"error","detail":"..."} then close.

    This is progressive synthesis, not guaranteed real-time or sub-10 ms latency.
    """
    await websocket.accept()
    reference_path: Path | None = None
    slot_acquired = False
    try:
        import base64
        import json
        import tempfile

        payload = await websocket.receive_json()
        if not isinstance(payload, dict):
            await websocket.send_json({"type": "error", "detail": "Expected a JSON object"})
            await websocket.close(code=1003)
            return

        if not payload.get("consent"):
            await websocket.send_json(
                {"type": "error", "detail": "Confirm permission to use the reference voice"}
            )
            await websocket.close(code=1008)
            return

        text_in = str(payload.get("text") or "").strip()
        if not text_in:
            await websocket.send_json({"type": "error", "detail": "Text must not be empty"})
            await websocket.close(code=1003)
            return

        language = str(payload.get("language") or "en")
        emotion_raw = str(payload.get("emotion") or "neutral")
        try:
            selected_emotion = Emotion(emotion_raw)
        except ValueError:
            choices = ", ".join(item.value for item in Emotion)
            await websocket.send_json(
                {"type": "error", "detail": f"Unsupported emotion. Choose one of: {choices}"}
            )
            await websocket.close(code=1003)
            return

        suffix = str(payload.get("reference_suffix") or ".wav").lower()
        if not suffix.startswith("."):
            suffix = f".{suffix}"
        if suffix not in _ALLOWED_SUFFIXES:
            await websocket.send_json({"type": "error", "detail": "Unsupported reference audio format"})
            await websocket.close(code=1003)
            return

        ref_b64 = payload.get("reference_b64")
        if not ref_b64 or not isinstance(ref_b64, str):
            await websocket.send_json({"type": "error", "detail": "reference_b64 is required"})
            await websocket.close(code=1003)
            return
        try:
            ref_bytes = base64.b64decode(ref_b64, validate=True)
        except Exception:
            await websocket.send_json({"type": "error", "detail": "Invalid reference_b64"})
            await websocket.close(code=1003)
            return
        if not ref_bytes:
            await websocket.send_json({"type": "error", "detail": "Reference audio is empty"})
            await websocket.close(code=1003)
            return
        if len(ref_bytes) > _MAX_UPLOAD_BYTES:
            await websocket.send_json({"type": "error", "detail": "Reference audio exceeds 25 MiB"})
            await websocket.close(code=1009)
            return

        slot_acquired = _synthesis_slot.acquire(blocking=False)
        if not slot_acquired:
            await websocket.send_json(
                {
                    "type": "error",
                    "detail": "ElevenX is already synthesizing audio. Wait, then retry.",
                    "retry_after": 3,
                }
            )
            await websocket.close(code=1013)
            return

        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as handle:
            reference_path = Path(handle.name)
            handle.write(ref_bytes)

        engine = get_engine()
        chunks_sent = 0

        # Progressive delivery: producer thread puts StreamChunk | Exception | None(sentinel)
        # on a queue so the event loop can send each sentence as soon as it is ready.
        import queue
        import threading as _threading

        q: queue.Queue = queue.Queue(maxsize=4)
        error_box: list = []

        def _producer() -> None:
            try:
                for chunk in engine.synthesize_stream(
                    text_in,
                    reference_path,
                    language,
                    selected_emotion.value,
                ):
                    q.put(chunk)
            except Exception as exc:  # noqa: BLE001 — forwarded to client
                error_box.append(exc)
            finally:
                q.put(None)

        worker = _threading.Thread(target=_producer, name="elevenx-stream", daemon=True)
        worker.start()

        meta_sent = False
        while True:
            item = await run_in_threadpool(q.get)
            if item is None:
                break
            if not meta_sent:
                await websocket.send_json(
                    {
                        "type": "meta",
                        "sample_rate": item.sample_rate,
                        "emotion": selected_emotion.value,
                        "total_chunks": item.total,
                        "mode": "progressive-sentence",
                        "note": (
                            "Progressive sentence synthesis. First-chunk latency includes "
                            "model load (if cold) and XTTS inference — not sub-10 ms."
                        ),
                    }
                )
                meta_sent = True
            await websocket.send_json(
                {
                    "type": "chunk",
                    "index": item.index,
                    "total": item.total,
                    "text": item.text,
                    "duration_seconds": item.duration_seconds,
                    "is_final": item.is_final,
                }
            )
            await websocket.send_bytes(item.audio.astype("float32").tobytes())
            chunks_sent += 1

        worker.join(timeout=5)
        if error_box:
            raise error_box[0]
        if chunks_sent == 0:
            await websocket.send_json({"type": "error", "detail": "No audio chunks produced"})
            await websocket.close(code=1011)
            return

        await websocket.send_json({"type": "done", "chunks": chunks_sent})
        logger.info("stream synthesis ok chunks=%d emotion=%s", chunks_sent, selected_emotion.value)
        await websocket.close(code=1000)
    except WebSocketDisconnect:
        logger.info("stream client disconnected")
    except (ValueError, FileNotFoundError, RuntimeError) as exc:
        logger.warning("stream client error: %s", exc)
        try:
            await websocket.send_json({"type": "error", "detail": str(exc)})
            await websocket.close(code=1003)
        except Exception:
            pass
    except Exception:
        logger.exception("stream synthesis failed")
        try:
            await websocket.send_json({"type": "error", "detail": "Internal synthesis error"})
            await websocket.close(code=1011)
        except Exception:
            pass
    finally:
        if slot_acquired:
            _synthesis_slot.release()
        if reference_path is not None:
            reference_path.unlink(missing_ok=True)
