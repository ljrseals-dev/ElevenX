# ElevenX archive integration status

Branch: `main` (post-audit)

## Scope and safety rules

This repository integrates selected ideas from `Source/ElevenX.zip` and `Source/AOC-Magic-v3-main.zip` into a **respectful, local-first** Python application. The existing XTTS-v2 synthesis API remains the compatibility baseline; archive code must not silently replace it.

- Keep `synthesize()` and `POST /v1/synthesize` compatible.
- Keep model loading lazy and inference serialized. A busy inference slot must continue to return HTTP 503 with `Retry-After`.
- Keep synthesis local-first. Do not add telemetry, remote model calls, or automatic update checks.
- Require explicit consent for voice cloning.
- Treat SpeechBrain ECAPA embeddings as optional analysis only unless an explicitly validated conditioning path is implemented.
- Do not enable HarmoniaCodec training/inference as a production codec without trained weights, reproducible quality tests, and documented model provenance.
- Keep TensorRT, Rust, TypeScript rendering, and the C++ spatial bridge optional and independently buildable; none may become a required runtime dependency without a separate design decision.
- Bind the HTTP server to loopback by default; never claim public exposure safety without auth, TLS, quotas, and consent controls.

## Archive audit (completed)

### `Source/ElevenX.zip`

Extracted and inspected. Contents:

| Path | Role | Status |
|------|------|--------|
| `python/elevenx_engine.py` | Full engine with streaming + spatial hooks | **Not imported wholesale.** Overclaims concurrency safety and sub-10 ms latency. Useful ideas (lazy load, emotion presets) already present in `src/elevenx/engine.py`. |
| `python/server.py` | FastAPI + WebSocket | **Not used.** Binds to `0.0.0.0`, no consent flag, no upload limits, no synthesis lock. Current `api.py` is strictly safer. |
| `python/watermark.py` | Meta AudioSeal wrapper | **Ported as optional** (`elevenx.watermark`). Disabled by default; requires extra dependency. |
| `python/spatial_audio.py` | Pure-Python spatial fallback | Left as future optional module; not wired into the active path. |
| `python/train_harmonia.py` | Training script stub | Not enabled. No trained weights ship. |
| `python/optimize_tensorrt.py` | TensorRT export helper | Optional; NVIDIA-only; not required. |
| `cpp/` | SpatialReverbBridge (CMake) | Optional external build; not a runtime dependency. |
| `rust/` | Ring buffer + streamer | Optional external build. |
| `typescript/` | AudioRenderer client | Optional external build. |

License note: archive README claims “Proprietary – ElevenX.ai”. The active repository carries its own LICENSE and does not absorb proprietary claims from the archive without explicit relicensing.

### `Source/AOC-Magic-v3-main.zip`

Contains a nested `aoc_magic_v3.zip` and a short README. The AOC-style arrangement contract already lives in `src/elevenx/studio.py` as a renderer-neutral planner. No automatic import of the nested archive was performed; the studio adapter remains the stable public surface.

## Work completed

- Full extraction and file-by-file review of both archives.
- `SECURITY.md`, `DEPENDENCIES.md`, and this status document kept accurate.
- Model-free engine/API tests covering sample-rate handling, concurrency rejection, consent, upload limits, and temporary-file cleanup.
- Optional ethical watermark module (`elevenx.watermark`) with clear opt-in and no effect on the default synthesis path.
- HarmoniaCodec kept behind a readiness gate; never on the hot path.
- Voice Studio UI and FastAPI surface remain loopback-oriented and consent-gated.

## What “finished” means for this milestone

A respectful, usable local voice studio that:

1. Synthesizes with XTTS-v2 from a user-supplied reference the caller confirms they may use.
2. Never exposes the API publicly by default.
3. Serializes model inference and returns 503 + Retry-After under load.
4. Offers emotion *style hints* (not calibrated emotion control).
5. Keeps advanced polyglot / spatial / codec pieces optional and documented.
6. Does not claim sub-10 ms latency, 99.97 % similarity, or production singing harmonies.

## Remaining future work (explicitly out of scope for this finish)

- Trained HarmoniaCodec weights + quality gates.
- Shared-memory ring buffer between Python and C++/Rust.
- Lower-latency token/streaming vocoder path (current stream is sentence-progressive, not token-level).
- Authenticated remote deployment.
- Validated musical harmony renderer for the studio adapter.

These are later milestones, not blockers for the current respectful prototype.
