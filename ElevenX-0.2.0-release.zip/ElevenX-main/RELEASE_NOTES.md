# ElevenX 0.2.0 — Release Notes

**Local-first voice synthesis**  
**Date:** 2026-10-27  
**Tag:** `v0.2.0`

> I don't compete. I replace.  
> Branding only — this release makes no measured claim against any cloud voice API.

---

## Highlights

ElevenX 0.2.0 turns the respectful XTTS prototype into a **local production-ready** voice studio:

- Progressive **sentence streaming** over WebSocket with live playback in the UI  
- First-class **CLI** (`elevenx info | synthesize | serve`)  
- Optional **ethical watermarking** (AudioSeal; off by default)  
- Hardened API: `/health`, `/ready`, `/v1/info`, consent-gated synthesize  
- **Dockerfile** for loopback-only container runs  
- Full audit of archived experimental sources (spatial, TensorRT, HarmoniaCodec kept optional)

Still local-first. Still consent-required. Still honest about limits.

---

## What's new

### Streaming
- `ElevenXEngine.synthesize_stream()` yields `StreamChunk` per sentence  
- WebSocket endpoint: `GET/WS /v1/synthesize/stream`  
- Voice Studio checkbox: **Stream sentences as they generate**  
- Protocol: JSON meta → (chunk meta + float32 PCM)… → done  
- Same consent, upload limits, and single-synthesis lock as HTTP  
- **Not** token-level or sub-10 ms; first chunk includes model load (if cold) + XTTS for sentence 1  

### CLI
```text
elevenx info
elevenx synthesize -t "Hello." -r reference.wav -o out.wav
elevenx serve --host 127.0.0.1 --port 8000
```
- `serve` refuses non-loopback binds unless `--allow-remote` is passed  

### API surface
| Endpoint | Role |
|----------|------|
| `GET /` | Voice Studio UI |
| `GET /health` | Liveness (no model load) |
| `GET /ready` | Engine constructible; reports device / busy |
| `GET /v1/info` | Capability statement (honest limits) |
| `POST /v1/synthesize` | Complete WAV (multipart + consent) |
| `WS /v1/synthesize/stream` | Progressive sentence PCM |

### Watermark (optional)
```bash
pip install -e ".[watermark]"
# config.yaml → watermark.enabled: true
```
Post-synthesis provenance only. Does **not** replace consent.

### Packaging
- Version **0.2.0** (`pyproject.toml`, config, API)  
- `Dockerfile` — publish port only to host `127.0.0.1`  
- Archive integration status documented in `docs/INTEGRATION_STATUS.md`  

---

## Hardening retained from 0.1.x

- Explicit **consent** on every synthesis request  
- Inference **serialized** — concurrent work → HTTP 503 + `Retry-After: 3`  
- Blocking model work off the event loop  
- Upload size cap (25 MiB), text length cap, format allow-list  
- Temp file cleanup on success and failure  
- Sample rate taken from the loaded model when available  
- Loopback default; see `SECURITY.md` before any remote exposure  

---

## Install

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -U pip
pip install -e ".[test]"

# optional
pip install -e ".[speaker]"        # ECAPA embeddings
pip install -e ".[watermark]"      # AudioSeal
```

```bash
elevenx serve --host 127.0.0.1 --port 8000
# open http://127.0.0.1:8000/
```

Docker:
```bash
docker build -t elevenx:0.2.0 .
docker run --rm -p 127.0.0.1:8000:8000 elevenx:0.2.0
```

---

## Breaking / behavior notes

- Package version is **0.2.0** (was 0.1.2).  
- `/v1/info` reports `"streaming": true` (sentence-progressive).  
- Streaming path does **not** apply watermark (partial audio is not marked).  
- CLI entry point `elevenx` requires an editable/install (`pip install -e .`).  

---

## Explicit non-goals (this release)

- No sub-10 ms end-to-end latency claim  
- No calibrated emotion control (presets are style hints)  
- No 99.97% speaker-similarity claim  
- HarmoniaCodec remains **disabled** without trained weights + quality gates  
- Spatial / C++ / Rust / TensorRT remain optional external builds  
- Not a public multi-tenant service without auth, TLS, quotas, and a real rights workflow  

---

## Files to read

| Doc | Purpose |
|-----|---------|
| `README.md` | Install, CLI, API, limitations |
| `SECURITY.md` | Loopback boundary, consent, remote prerequisites |
| `docs/INTEGRATION_STATUS.md` | Archive audit + safety rules |
| `CHANGELOG.md` | Machine-oriented change list |
| `DEPENDENCIES.md` | Runtime + optional dependency inventory |

---

## Verify

```bash
pip install -e ".[test]"
python -m pytest                 # model-free suite
python scripts/smoke_xtts.py --reference /path/to/consented.wav --output smoke.wav
```

Model-free tests do **not** prove GPU quality or real XTTS inference on your machine. Use the smoke script for that.

---

## Thanks / posture

Built to be owned and run locally — not rented by the character.  
Use only voices you have permission to synthesize.
