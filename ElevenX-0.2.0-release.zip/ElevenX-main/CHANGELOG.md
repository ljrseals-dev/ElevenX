# Changelog

## 0.2.0 — Production-ready local milestone

### Added
- Progressive sentence streaming over WebSocket (`/v1/synthesize/stream`) with live UI playback
- `StreamChunk` + `synthesize_stream()` on the engine (sentence-level PCM yield)
- CLI: `elevenx info | synthesize | serve`
- `/ready` readiness endpoint and `/v1/info` capability statement
- Optional ethical watermark integrated into the synthesis path when `watermark.enabled: true`
- Dockerfile for local container runs (publish only to host loopback)
- Structured logging on successful and failed synthesis

### Hardened
- API version aligned to 0.2.0
- Explicit refusal to bind outside loopback from the CLI unless `--allow-remote` is passed
- Clearer consent and security messaging retained
- Concurrent synthesis still returns HTTP 503 + `Retry-After: 3`

### Explicit non-goals (still)
- No claim of sub-10 ms latency or calibrated emotion control
- HarmoniaCodec remains disabled without trained weights + quality gates
- No public multi-tenant deployment without auth, TLS, quotas, and rights workflow

## 0.1.2

Baseline respectful XTTS prototype with consent, serialization, and Voice Studio UI.
