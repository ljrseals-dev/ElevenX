"""Model-free tests for the optional watermark helper."""
from __future__ import annotations

import numpy as np
import pytest

from elevenx.watermark import WatermarkResult, maybe_watermark


def test_maybe_watermark_disabled_is_noop():
    audio = np.zeros(2400, dtype=np.float32)
    result = maybe_watermark(audio, 24000, enabled=False)
    assert isinstance(result, WatermarkResult)
    assert result.applied is False
    assert result.message == ""
    assert result.sample_rate == 24000
    np.testing.assert_array_equal(result.audio, audio)


def test_maybe_watermark_enabled_without_audioseal_raises():
    audio = np.zeros(2400, dtype=np.float32)
    with pytest.raises(RuntimeError, match="AudioSeal is not installed"):
        maybe_watermark(audio, 24000, enabled=True)
