"""Model-free tests for progressive sentence streaming helpers."""
from __future__ import annotations

from elevenx.engine import split_sentences


def test_split_sentences_basic():
    parts = split_sentences("Hello there. How are you? Fine!")
    assert parts == ["Hello there.", "How are you?", "Fine!"]


def test_split_sentences_merges_short_tail():
    parts = split_sentences("This is a long enough sentence. Ok.")
    assert len(parts) >= 1
    assert parts[0].startswith("This is a long enough sentence")


def test_split_sentences_empty():
    assert split_sentences("   ") == []
    assert split_sentences("") == []


def test_split_sentences_single():
    assert split_sentences("No terminal punctuation here") == [
        "No terminal punctuation here"
    ]
